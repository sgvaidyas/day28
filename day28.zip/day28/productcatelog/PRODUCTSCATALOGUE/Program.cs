﻿using System;
using System.IO;

namespace PRODUCTSCATALOGUE
{
    class Program
    {
        static void Main(string[] args)
        {
            float bill = 0;
            StreamWriter sw = new StreamWriter("E:\\Orders.txt ", true);
            int ch;
            do
            {
                Orders ob = new Orders();
                ob.display();
                bill += ob.totprice ;
                sw.WriteLine(ob.Mydata());
                Console.WriteLine("_______________________");
                Console.WriteLine("If you want to continue shopping PRESS 1");
                ch = int.Parse(Console.ReadLine());
            } while (ch==1);
            Console.WriteLine("BILL = " + bill);

            sw.Close();
        }
    }
}
