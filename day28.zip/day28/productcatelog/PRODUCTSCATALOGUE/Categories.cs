﻿using System;

namespace PRODUCTSCATALOGUE
{
    class Categories
    {
        public int catid;
        public string catname, cattype;

        public Categories()
        {
            Console.WriteLine("Enter the CATEGORY ID = ");
            catid = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the CATEGORY NAME = ");
            catname = Console.ReadLine();
            Console.WriteLine("Enter the CATEGORY TYPE = ");
            cattype = Console.ReadLine();
        }
        public void display()
        {
            Console.WriteLine("CAT ID         " + catid);
            Console.WriteLine("CAT NAME      " + catname);
            Console.WriteLine("CAT TYPE      " + cattype);
        }
    }
}
