﻿using System;
using System.IO;

namespace PRODUCTSCATALOGUE
{
    class ReadData
    {
        static void Main(string[] args)
        {
            StreamReader sr = new StreamReader("E:\\Orders.txt");
            string line;

            Console.WriteLine("Enter Product name = ");
            string pdname = Console.ReadLine();
            
            while((line = sr.ReadLine())!=null )
            {
                string[] content = line.Split('|');
                if (content.Length > 5)
                {
                    if (content[5].Substring(17).Contains(pdname))
                    {
                        foreach (string x in content)
                            Console.WriteLine(x);
                        break;
                    }
                }                               
                Console.WriteLine("\n\n");
            }                
            sr.Close();
        }
    }
}
