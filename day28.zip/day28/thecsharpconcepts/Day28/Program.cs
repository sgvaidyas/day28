﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day28
{
    class Program
    {
        static void myfun(params int[] val )
        {
            for(int i=0;i<val.Length;i++)
                Console.WriteLine(val[i]);

        }
        static void myfun1(params object[] val)
        {
            for (int i = 0; i < val.Length; i++)
                Console.WriteLine(val[i]);

        }
        static void Main(string[] args)
        {
            myfun(22,3,4,55,7,8);
            Console.WriteLine("____________________");
            myfun1("Apple", 44, 7.8, 'A');
        }
    }
}
